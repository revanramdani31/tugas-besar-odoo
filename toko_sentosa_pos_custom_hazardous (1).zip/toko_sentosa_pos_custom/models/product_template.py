from odoo import models, fields


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    x_is_hazardous = fields.Boolean(
        string='Produk Berbahaya',
        default=False,
        help='Centang jika produk ini mengandung bahan berbahaya atau merupakan benda tajam. '
             'Sistem POS akan menampilkan peringatan khusus saat kasir menambahkan produk ini.'
    )
    x_hazard_type = fields.Selection([
        ('chemical',  'Mengandung Zat Kimia Berbahaya'),
        ('sharp',     'Benda Tajam / Berpotensi Melukai'),
        ('flammable', 'Mudah Terbakar / Flamable'),
        ('other',     'Bahaya Lainnya'),
    ], string='Jenis Bahaya')

    x_hazard_notes = fields.Char(
        string='Catatan Bahaya / SOP',
        help='Instruksi penanganan yang ditampilkan kepada kasir di POS.'
    )


class ProductProduct(models.Model):
    """
    Odoo POS me-load data produk dari model product.product (bukan product.template).
    Kita perlu override _get_pos_ui_product_product_fields agar field x_is_hazardous,
    x_hazard_type, dan x_hazard_notes ikut dikirim ke frontend POS.
    """
    _inherit = 'product.product'

    def _get_pos_ui_product_product_fields(self):
        fields = super()._get_pos_ui_product_product_fields()
        fields += ['x_is_hazardous', 'x_hazard_type', 'x_hazard_notes']
        return fields
