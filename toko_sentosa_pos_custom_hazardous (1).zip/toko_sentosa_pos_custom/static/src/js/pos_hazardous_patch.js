/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { ProductCard } from "@point_of_sale/app/components/product_card/product_card";
import { HazardousItemPopup } from "@toko_sentosa_pos_custom/js/hazardous_item_popup";

// Path ProductCard confirmed: .../app/components/product_card/product_card.js
// Patch selectProduct() yang dipanggil setiap kali kartu produk diklik / scan barcode

patch(ProductCard.prototype, {

    async selectProduct() {
        const product = this.props.product;
        const isHazardous = product?.x_is_hazardous
            ?? product?.raw?.x_is_hazardous
            ?? false;

        if (isHazardous) {
            const confirmed = await new Promise((resolve) => {
                this.env.services.popup.add(HazardousItemPopup, {
                    product:   product,
                    onConfirm: () => resolve(true),
                    onCancel:  () => resolve(false),
                });
            });
            if (!confirmed) return;
        }

        return super.selectProduct(...arguments);
    },
});
