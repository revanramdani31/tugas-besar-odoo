from odoo import models, fields


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    x_is_hazardous = fields.Boolean(
        string='Produk Berbahaya',
        default=False,
        help='Centang jika produk ini mengandung bahan berbahaya atau merupakan benda tajam. '
             'Sistem POS akan menampilkan peringatan khusus saat kasir menambahkan produk ini.'
    )
    x_hazard_type = fields.Selection([
        ('chemical', 'Mengandung Zat Kimia Berbahaya'),
        ('sharp', 'Benda Tajam / Berpotensi Melukai'),
        ('flammable', 'Mudah Terbakar / Flamable'),
        ('other', 'Bahaya Lainnya'),
    ], string='Jenis Bahaya',
        help='Pilih jenis bahaya produk untuk menentukan teks peringatan yang ditampilkan di POS.'
    )
    x_hazard_notes = fields.Char(
        string='Catatan Bahaya',
        help='Instruksi atau catatan penanganan khusus yang akan ditampilkan kepada kasir (opsional).'
    )
