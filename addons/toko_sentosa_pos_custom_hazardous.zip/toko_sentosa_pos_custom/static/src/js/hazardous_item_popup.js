/** @odoo-module */

import { Component } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";

/**
 * Popup peringatan yang muncul saat kasir menambahkan produk berbahaya.
 * Menampilkan ikon bahaya, nama produk, jenis bahaya, dan catatan SOP.
 * Kasir wajib mengkonfirmasi atau membatalkan sebelum lanjut.
 */
export class HazardousItemPopup extends Component {
    static template = "toko_sentosa_pos_custom.HazardousItemPopup";

    // Label bahasa Indonesia untuk setiap jenis bahaya
    static HAZARD_LABELS = {
        chemical: "Mengandung Zat Kimia Berbahaya",
        sharp: "Benda Tajam / Berpotensi Melukai",
        flammable: "Mudah Terbakar / Flammable",
        other: "Bahaya Lainnya",
    };

    // Ikon & warna per jenis bahaya
    static HAZARD_CONFIG = {
        chemical: { icon: "fa-flask", color: "#e67e22", bg: "#fef9e7" },
        sharp: { icon: "fa-cut", color: "#e74c3c", bg: "#fdedec" },
        flammable: { icon: "fa-fire", color: "#c0392b", bg: "#fdedec" },
        other: { icon: "fa-exclamation-triangle", color: "#f39c12", bg: "#fef9e7" },
    };

    setup() {
        this.pos = usePos();
    }

    get hazardLabel() {
        const type = this.props.product.x_hazard_type;
        return HazardousItemPopup.HAZARD_LABELS[type] || "Produk Berbahaya";
    }

    get hazardConfig() {
        const type = this.props.product.x_hazard_type || "other";
        return HazardousItemPopup.HAZARD_CONFIG[type];
    }

    get hazardNotes() {
        return this.props.product.x_hazard_notes || null;
    }

    confirm() {
        this.props.close();
        this.props.onConfirm();
    }

    cancel() {
        this.props.close();
        this.props.onCancel();
    }
}
