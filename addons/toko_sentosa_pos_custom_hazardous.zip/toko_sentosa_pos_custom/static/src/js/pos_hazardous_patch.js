/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { HazardousItemPopup } from "@toko_sentosa_pos_custom/js/hazardous_item_popup";

// ─────────────────────────────────────────────────────────────────────────────
// Patch PosStore: cegat addProductToCurrentOrder agar cek hazardous terlebih
// dahulu sebelum produk benar-benar masuk ke keranjang.
// ─────────────────────────────────────────────────────────────────────────────
patch(PosStore.prototype, {
    /**
     * Override method yang dipanggil setiap kali produk ditambahkan ke order,
     * baik via klik, barcode scan, maupun numpad.
     */
    async addProductToCurrentOrder(product, options = {}) {
        // Cek apakah produk ditandai berbahaya
        if (product.x_is_hazardous) {
            const confirmed = await this._showHazardousWarning(product);
            // Jika kasir memilih "Batal", jangan tambahkan produk
            if (!confirmed) {
                return;
            }
        }
        // Lanjutkan ke behaviour normal Odoo POS
        return super.addProductToCurrentOrder(product, options);
    },

    /**
     * Tampilkan HazardousItemPopup dan kembalikan Promise<boolean>:
     *   true  → kasir memilih "Lanjutkan"
     *   false → kasir memilih "Batal"
     */
    async _showHazardousWarning(product) {
        return new Promise((resolve) => {
            this.env.services.popup.add(HazardousItemPopup, {
                product: product,
                onConfirm: () => resolve(true),
                onCancel: () => resolve(false),
            });
        });
    },
});
